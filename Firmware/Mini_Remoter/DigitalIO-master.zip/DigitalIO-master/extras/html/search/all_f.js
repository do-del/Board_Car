var searchData=
[
  ['toggle',['toggle',['../class_digital_pin.html#ab2109c522836448cd6dfd576c1b5a5a0',1,'DigitalPin::toggle()'],['../class_pin_i_o.html#ad2d6131f6d1a85a5384915e3390fc9bc',1,'PinIO::toggle()']]],
  ['transfer',['transfer',['../group__soft_i2_c.html#gab4ce251351fbcc55682ae97191a7e356',1,'I2cMasterBase::transfer()'],['../class_soft_s_p_i.html#a519d107f7d6aabfe78260504a6ac6bf5',1,'SoftSPI::transfer()']]],
  ['transfercontinue',['transferContinue',['../group__soft_i2_c.html#ga452971cabe06c55b1ba61c5d47b72b0a',1,'I2cMasterBase']]]
];
